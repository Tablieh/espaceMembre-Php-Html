<?php

try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8', 'root', 'root');
    }
    catch(Exception $a)
    { 
        die('Erreur: '.$a->getMessage());
    }

?>