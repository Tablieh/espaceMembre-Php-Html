<?php session_start(); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Inscription</title>
</head>
<body>
  
  <?php
      if(isset($_GET['message'])){
        echo $_GET['message'];
      }
      if(isset($_SESSION['pseudo'])){
        echo "Vous êtes déjà connecté en tant que ".$_SESSION['pseudo'];
      }

  ?>

<div class="topnav">
<?php if(isset($_SESSION['pseudo'])){ //ajout de l'onglet accueil si un utilisateur est connecté ?>
      <a href="../views/accueil.php">Accueil</a>
  <?php  } ?>
  <a href="pageConnexion.php">Connexion</a>
  <a class="active" href="pageInscription.php">Inscription</a>
    <?php if(isset($_SESSION['pseudo'])){ ?>
      <a href="../controllers/deconnexion.php">Deconnexion</a>
    <?php  } ?>
</div><br><br>


<div>Inscription</div>
<form action="../controllers/inscription.php" method="post">
    
    <input type="text" placeholder="Votre pseudo" name="pseudo"><br>
    <input type="email" placeholder="Votre email" name="mail"><br>
    <input type="password" placeholder="Votre mot de passe" name="pass"><br>
    <input type="password" placeholder="Confirmez votre mot de passe" name="confpass"><br>
    <input type="submit" value="S'inscrire">
    
</form>


</body>
</html>