<?php session_start(); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Connexion</title>
</head>
<body>

  <?php
      if(isset($_GET['message'])){
        echo $_GET['message'];
      }

      if(isset($_SESSION['pseudo'])){
        echo "Vous êtes déjà connecté en tant que ".$_SESSION['pseudo'];
      }
  ?>

<div class="topnav">

<?php if(isset($_SESSION['pseudo'])){ //ajout de l'onglet accueil si un utilisateur est connecté ?>
      <a href="../views/accueil.php">Accueil</a>
  <?php  } ?>
  <a class="active" href="pageConnexion.php">Connexion</a>
  <a href="pageInscription.php">Inscription</a>
    <?php if(isset($_SESSION['pseudo'])){ ?>
      <a href="../controllers/deconnexion.php">Deconnexion</a>
    <?php  } ?>
</div><br><br>

<div>Connexion</div>
<form action="../controllers/connexion.php" method="post">
    
    <input type="text" placeholder="Pseudo" name="pseudo"><br>
    <input type="password" placeholder="Mot de passe" name="pass"><br>
   
    <input type="submit" value="Se connecter">
    
</form>

</body>
</html>