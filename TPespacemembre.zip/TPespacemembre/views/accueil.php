<?php session_start(); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Accueil</title>
</head>
<body>
    
<div class="topnav">
  <a class="active" href="accueil.php">Accueil</a>
  <a href="pageConnexion.php">Connexion</a>
  <a href="pageInscription.php">Inscription</a>
    <?php if(isset($_SESSION['pseudo'])){ ?>
      <a href="../controllers/deconnexion.php">Deconnexion</a>
    <?php  } ?>
</div>

    <?php echo "Bonjour ".$_SESSION['pseudo']." ! Vous êtes connecté !"; ?>

<br>

    

</body>
</html>