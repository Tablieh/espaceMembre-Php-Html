<?php 



if(isset($_POST['pseudo'], $_POST['pass'])){
    
    //model connexion à la base de donnée
    include '../models/connexion_bdd.php';

    $pseudo = htmlspecialchars($_POST['pseudo']);


    //  Récupération de l'utilisateur et de son pass hashé
    $req = $bdd->prepare('SELECT id, pass FROM membres WHERE pseudo = :pseudo');
    $req->execute(array(
        'pseudo' => $pseudo));
    $resultat = $req->fetch();

    // Comparaison du pass envoyé via le formulaire avec celui en base de données (avec password_verify() pour comparer le hashage)
    $isPasswordCorrect = password_verify($_POST['pass'], $resultat['pass']);

    if (!$resultat)
    {
        $message = "Mauvais identifiant ou mot de passe !";
        header('Location: ../views/pageConnexion.php?message='.$message);
    }
    else
    {
        if ($isPasswordCorrect) {
            session_start();
            $_SESSION['id'] = $resultat['id'];
            $_SESSION['pseudo'] = $pseudo;

            header('Location: ../views/accueil.php');
        }
        else {

            $message = "Mauvais identifiant ou mot de passe !";
            header('Location: ../views/pageConnexion.php?message='.$message);

        }
    }
}else{

    $message = "Veuillez entrer un pseudo et un mot de passe";
    header('Location: ../views/pageConnexion.php?message='.$message);
}
?>