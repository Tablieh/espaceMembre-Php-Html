
    <?php
    if(isset($_POST['pseudo'], $_POST['mail'], $_POST['pass'])){

        //model connexion à la base de donnée
        include '../models/connexion_bdd.php';


        //recuperation des données ( de mon formulaire d'inscription via la method POST )
        $pseudo = htmlspecialchars($_POST['pseudo']);
        $email = htmlspecialchars($_POST['mail']);
        $pass = htmlspecialchars($_POST['pass']);
        $confpass = htmlspecialchars($_POST['confpass']);

        //verification de la validité des information
        $reponse = $bdd->query("SELECT pseudo FROM membres WHERE pseudo='$pseudo'");
        $donnees = $reponse->fetch();

        //pseudo existant ? (s'il y a une réponse à la requete c'est que le pseudo existe déjà)
        if($donnees >= 1){

            $reponse->closeCursor();

            $message = "Le pseudo est déjà utilisé";
            header('Location: ../views/pageInscription.php?message='.$message);
            
       
        }
         //correspondance des mdp
        elseif($pass != $confpass){

            $message = "Les mot de passe doivent correspondre";
            header('Location: ../views/pageInscription.php?message='.$message);

             
        }
         //verification de l'adresse mail avec une expression régulière
        elseif(preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $email)){

      

            //preparation de la requete et insertion en base de donnée
            $req = $bdd->prepare('INSERT INTO membres (pseudo, pass, email, date_inscription) VALUES(?, ?, ?, ?)');

            //mdp hash
            $pass_hash = password_hash($pass, PASSWORD_DEFAULT);

            $req->execute(array($pseudo, $pass_hash, $email, date("Y-m-d")));

            header('Location: ../views/pageConnexion.php');
           
        }
        else{

            //si l'adresse mail n'est pas valide
            $message = "L'adresse mail n'est pas valide";
            header('Location: ../views/pageInscription.php?message='.$message);
        }
    }
    ?>
