<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
  <?php
    if(isset($_GET['message'])){
      echo $_GET['message'];
    }
  ?>
<div class="topnav">
  <a href="views/pageConnexion.php">Connexion</a>
  <a href="views/pageInscription.php">Inscription</a>
</div>

</body>
</html>